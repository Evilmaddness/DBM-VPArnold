DBM Arnold Voicepack 
==================

This is Arnold voicepack for DBM. 

To start your own DBM voice pack, download the demo and follow the HowTo.txt.

# zip -r DBM-VPDemo-<version>.zip DBM-VPDemo/
 